export enum FrameType {
  None = 'none',
  Black = 'black',
  White = 'white',
}

export enum ArtworkType {
  Painting = 'painting',
  Statue = 'statue',
}
