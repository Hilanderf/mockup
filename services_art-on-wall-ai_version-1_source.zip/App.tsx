import React, { useState, useCallback } from 'react';
import ImageUploader from './components/ImageUploader';
import ArtworkTypeSelector from './components/ArtworkTypeSelector';
import FrameSelector from './components/FrameSelector';
import ResultDisplay from './components/ResultDisplay';
import { generateArtwork } from './services/geminiService';
import { ArtworkType, FrameType } from './types';

const App: React.FC = () => {
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [artworkType, setArtworkType] = useState<ArtworkType>(ArtworkType.Painting);
  const [frameType, setFrameType] = useState<FrameType>(FrameType.None);
  
  const [result, setResult] = useState<{ imageUrl: string | null; text: string | null }>({ imageUrl: null, text: null });
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (file: File | null) => {
    setImageFile(file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    } else {
      setPreview(null);
    }
  };

  const handleGenerateClick = useCallback(async () => {
    if (!imageFile) {
      setError("Veuillez sélectionner une image.");
      return;
    }
    
    setIsLoading(true);
    setError(null);
    setResult({ imageUrl: null, text: null });

    try {
      const response = await generateArtwork(imageFile, artworkType, frameType);
      setResult(response);
    } catch (e: any) {
      setError(e.message || "Une erreur inconnue est survenue.");
    } finally {
      setIsLoading(false);
    }
  }, [imageFile, artworkType, frameType]);
  
  const handleReset = () => {
    setImageFile(null);
    setPreview(null);
    setArtworkType(ArtworkType.Painting);
    setFrameType(FrameType.None);
    setResult({ imageUrl: null, text: null });
    setIsLoading(false);
    setError(null);
  };

  const isFormComplete = imageFile !== null;

  if (isLoading || error || result.imageUrl) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="max-w-2xl w-full">
          <ResultDisplay 
            isLoading={isLoading}
            error={error}
            imageUrl={result.imageUrl}
            text={result.text}
            onReset={handleReset}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl mx-auto bg-white rounded-xl shadow-lg p-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800">Transformez votre art</h1>
          <p className="text-gray-500 mt-2">Téléchargez une photo de votre œuvre et laissez l'IA la sublimer.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Uploader & Options */}
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-gray-700 mb-2">1. Téléchargez votre image</h2>
              <ImageUploader onImageChange={handleImageChange} preview={preview} />
            </div>
            
            <div>
              <h2 className="text-lg font-semibold text-gray-700 mb-2">2. Choisissez le type d'œuvre</h2>
              <ArtworkTypeSelector selectedArtworkType={artworkType} onArtworkTypeChange={setArtworkType} />
            </div>
            
            {artworkType === ArtworkType.Painting && (
              <div>
                <h2 className="text-lg font-semibold text-gray-700 mb-2">3. Choisissez un cadre</h2>
                <FrameSelector selectedFrame={frameType} onFrameChange={setFrameType} />
              </div>
            )}
          </div>
          
          {/* Right Column: Preview & Action */}
          <div className="flex flex-col">
            <div className="flex-grow space-y-6">
                <h2 className="text-lg font-semibold text-gray-700 mb-2">Aperçu</h2>
                <div className="w-full h-64 border-2 border-gray-200 rounded-lg bg-gray-50 flex items-center justify-center">
                   {preview ? (
                     <img src={preview} alt="Aperçu" className="max-h-full max-w-full object-contain rounded-lg" />
                   ) : (
                     <div className="text-center text-gray-400">
                        <p>L'aperçu de votre image apparaîtra ici.</p>
                     </div>
                   )}
                </div>
            </div>

            <div className="mt-8">
                <button
                    onClick={handleGenerateClick}
                    disabled={!isFormComplete || isLoading}
                    className="w-full bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed transition-all duration-300"
                >
                    {isLoading ? 'Génération en cours...' : 'Générer la nouvelle image'}
                </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
